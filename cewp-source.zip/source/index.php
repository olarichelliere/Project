<?php

phpinfo();
